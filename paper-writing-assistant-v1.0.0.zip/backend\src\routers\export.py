"""
导出路由 - 处理论文导出功能
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import tempfile
import os

from database import get_db
from models.project import Project
from models.outline import Outline
from models.content import Content
from models.literature import Literature
from schemas.api import ExportRequest, ExportResponse
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects/{project_id}/export", tags=["导出"])
logger = get_logger("router.export")

@router.post("", response_model=ExportResponse)
async def export_paper(
    project_id: str,
    request: ExportRequest,
    db: AsyncSession = Depends(get_db)
):
    """导出论文"""
    project = (await db.execute(select(Project).where(Project.id == project_id))).scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    outline = (await db.execute(select(Outline).where(Outline.project_id == project_id))).scalar_one_or_none()
    if not outline:
        raise HTTPException(status_code=404, detail="大纲不存在")

    contents = (await db.execute(select(Content).where(Content.project_id == project_id))).scalars().all()
    literature = (await db.execute(select(Literature).where(Literature.project_id == project_id))).scalars().all()

    content_dict = {c.section_id: c for c in contents}
    sections = outline.structure.get("sections", [])

    paper_text = f"# {project.title}\n\n"

    if request.include_abstract:
        abstract_section = content_dict.get("1")
        if abstract_section and abstract_section.content:
            paper_text += "## 摘要\n\n"
            paper_text += abstract_section.content + "\n\n"

    for section in sections:
        if section["id"] == "1":
            continue
        content_obj = content_dict.get(section["id"])
        if content_obj and content_obj.content:
            paper_text += f"## {section['title']}\n\n"
            paper_text += content_obj.content + "\n\n"

    if request.include_references and literature:
        paper_text += "## 参考文献\n\n"
        for lit in literature:
            if lit.citation_key:
                paper_text += f"- [{lit.citation_key}] {lit.authors}. {lit.title}"
                if lit.publication_year:
                    paper_text += f" ({lit.publication_year})"
                if lit.doi:
                    paper_text += f". DOI: {lit.doi}"
                paper_text += "\n"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write(paper_text)
        temp_path = f.name

    return ExportResponse(
        success=True,
        data={"path": temp_path, "format": request.format},
        message="论文导出成功"
    )
