"""
文献管理路由 - 处理文献检索和列表操作
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from typing import List

from database import get_db
from models.project import Project
from models.literature import Literature
from schemas.api import (
    LiteratureResponse, LiteratureSearchRequest,
    LiteratureSearchResponse, SuccessResponse
)
from agents.literature_search import LiteratureSearchAgent
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects/{project_id}/literature", tags=["文献管理"])
logger = get_logger("router.literature")
search_agent = LiteratureSearchAgent()

@router.post("/search", response_model=LiteratureSearchResponse)
async def search_literature(
    project_id: str,
    request: LiteratureSearchRequest,
    db: AsyncSession = Depends(get_db)
):
    """搜索文献"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    literature = await search_agent.execute(request.topic, request.max_results)

    for lit in literature:
        lit.project_id = project_id
        db.add(Literature(**lit.model_dump()))

    await db.commit()

    return LiteratureSearchResponse(
        data=literature,
        total=len(literature)
    )

@router.get("", response_model=List[LiteratureResponse])
async def list_literature(
    project_id: str,
    db: AsyncSession = Depends(get_db)
):
    """获取文献列表"""
    result = await db.execute(
        select(Literature).where(Literature.project_id == project_id)
    )
    return result.scalars().all()

@router.delete("/{literature_id}", response_model=SuccessResponse)
async def delete_literature(
    project_id: str,
    literature_id: str,
    db: AsyncSession = Depends(get_db)
):
    """删除文献"""
    result = await db.execute(
        delete(Literature).where(
            Literature.id == literature_id,
            Literature.project_id == project_id
        )
    )
    await db.commit()
    return SuccessResponse(success=True, message="文献删除成功")
