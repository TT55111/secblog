"""
内容数据模型 - 定义论文内容的的数据结构
"""
from sqlalchemy import Column, String, DateTime, Text, Integer, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from database import Base

class Content(Base):
    """论文内容数据模型"""
    __tablename__ = "contents"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    project_id = Column(String(36), ForeignKey("projects.id"), nullable=False)
    section_id = Column(String(100), nullable=False)
    section_title = Column(String(500))
    content = Column(Text)
    ai_generated = Column(Boolean, default=False)
    token_count = Column(Integer, default=0)
    generated_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="contents")
