"""
大纲数据模型 - 定义论文大纲的数据结构
"""
from sqlalchemy import Column, String, DateTime, Text, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from database import Base

class Outline(Base):
    """论文大纲数据模型"""
    __tablename__ = "outlines"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    project_id = Column(String(36), ForeignKey("projects.id"), unique=True, nullable=False)
    structure = Column(JSON, nullable=False)
    generated_at = Column(DateTime, default=datetime.utcnow)
    user_modified = Column(Boolean, default=False)

    project = relationship("Project", back_populates="outline")
