"""
格式校验页面 - 处理论文格式校验
"""
import streamlit as st
import requests

def main():
    """格式校验页面主函数"""
    st.header("格式校验")

    if not st.session_state.get("current_project"):
        st.warning("请先在「项目管理」中选择一个项目")
        return

    project = st.session_state.current_project

    if st.button("🔍 开始校验", type="primary"):
        with st.spinner("正在校验..."):
            try:
                response = requests.post(
                    f"{st.session_state.api_base_url}/api/projects/{project['id']}/validate"
                )
                if response.status_code == 200:
                    data = response.json()
                    report = data.get("data", {})

                    st.subheader(f"校验结果: {report.get('total_errors', 0)} 个错误")

                    errors = report.get("errors", [])
                    if errors:
                        for error in errors:
                            with st.error(f"❌ {error.get('message')}"):
                                st.write(f"位置: {error.get('section_id', '未知')}")
                                if error.get('suggestion'):
                                    st.write(f"建议: {error.get('suggestion')}")
                    else:
                        st.success("✅ 未发现格式错误")

                    warnings = report.get("warnings", [])
                    if warnings:
                        st.subheader("⚠️ 警告")
                        for warning in warnings:
                            st.warning(warning)
                else:
                    st.error(f"校验失败: {response.text}")
            except Exception as e:
                st.error(f"连接错误: {str(e)}")

if __name__ == "__main__":
    main()
