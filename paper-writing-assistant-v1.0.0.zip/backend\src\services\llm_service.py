"""
LLM服务模块 - 封装LiteLLM统一接口，支持多种AI模型
"""
from litellm import acompletion, completion_cost
from typing import Optional, List, Dict, Any, AsyncGenerator
import os

from config import settings
from utils.logger import get_logger
from utils.exceptions import APIKeyMissingError, APIQuotaExceededError

logger = get_logger("llm_service")

class LLMService:
    """
    LLM服务类 - 提供统一的AI模型调用接口
    支持OpenAI、Claude、文心一言等多种模型
    """

    def __init__(self, model: Optional[str] = None, api_key: Optional[str] = None):
        """
        初始化LLM服务

        Args:
            model: 模型名称，默认为配置中的default_model
            api_key: API密钥，默认为环境变量中的OPENAI_API_KEY
        """
        self.model = model or settings.default_model
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.api_base = settings.api_base_url

    def _prepare_kwargs(self, **kwargs) -> dict:
        """
        准备LiteLLM调用参数

        Args:
            **kwargs: 其他调用参数

        Returns:
            dict: 准备好的调用参数字典
        """
        prepare_kwargs = {
            "model": self.model,
            **kwargs
        }
        if self.api_key:
            prepare_kwargs["api_key"] = self.api_key
        if self.api_base:
            prepare_kwargs["api_base"] = self.api_base
        return prepare_kwargs

    async def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> tuple[str, float]:
        """
        异步生成文本内容

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数，控制随机性
            max_tokens: 最大token数
            **kwargs: 其他LiteLLM参数

        Returns:
            tuple[str, float]: (生成的文本内容, 消耗成本)

        Raises:
            APIKeyMissingError: API Key未配置
            APIQuotaExceededError: API配额超限
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        try:
            response = await acompletion(
                **self._prepare_kwargs(),
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens or settings.max_token_per_request
            )
            content = response.choices[0].message.content
            cost = completion_cost(response)
            logger.info(f"LLM调用成功，模型: {self.model}, 消耗: ${cost:.4f}")
            return content, cost
        except Exception as e:
            error_str = str(e)
            if "api_key" in error_str.lower() or "auth" in error_str.lower():
                raise APIKeyMissingError(self.model)
            elif "quota" in error_str.lower() or "limit" in error_str.lower():
                raise APIQuotaExceededError(self.model)
            else:
                logger.error(f"LLM调用失败: {error_str}")
                raise

    async def generate_streaming(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """
        异步流式生成文本内容

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            **kwargs: 其他LiteLLM参数

        Yields:
            str: 生成的文本片段
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        try:
            response = await acompletion(
                **self._prepare_kwargs(),
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens or settings.max_token_per_request,
                stream=True
            )
            async for chunk in response:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            logger.error(f"LLM流式调用失败: {str(e)}")
            raise

llm_service = LLMService()
