"""
项目数据模型 - 定义论文项目的数据结构
"""
from sqlalchemy import Column, String, DateTime, Enum, Text
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
import enum

from database import Base

class ProjectStatus(str, enum.Enum):
    """项目状态枚举"""
    DRAFT = "draft"
    OUTLINE_COMPLETE = "outline_complete"
    DRAFT_COMPLETE = "draft_complete"
    FINAL = "final"

class Project(Base):
    """论文项目数据模型"""
    __tablename__ = "projects"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String(500), nullable=False)
    topic = Column(String(1000), nullable=False)
    format_template = Column(String(100), default="gb_t_7714")
    status = Column(Enum(ProjectStatus), default=ProjectStatus.DRAFT)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    literature = relationship("Literature", back_populates="project", cascade="all, delete-orphan")
    outline = relationship("Outline", back_populates="project", uselist=False, cascade="all, delete-orphan")
    contents = relationship("Content", back_populates="project", cascade="all, delete-orphan")
