"""
数据库模块 - 配置SQLAlchemy异步引擎和会话管理
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from config import settings
from pathlib import Path

DATA_DIR = Path(settings.database_url.replace("sqlite+aiosqlite:///", ""))
DATA_DIR.parent.mkdir(parents=True, exist_ok=True)

engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    future=True
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

Base = declarative_base()

async def get_db() -> AsyncSession:
    """
    获取数据库会话的依赖注入函数
    用于FastAPI路由中注入数据库会话

    Yields:
        AsyncSession: 异步数据库会话
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

async def init_db():
    """初始化数据库，创建所有表结构"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
