"""
项目管理路由 - 处理论文项目的CRUD操作
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List

from database import get_db
from models.project import Project, ProjectStatus
from schemas.api import (
    ProjectCreate, ProjectUpdate, ProjectResponse,
    ProjectListResponse, SuccessResponse
)
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects", tags=["项目管理"])
logger = get_logger("router.projects")

@router.post("", response_model=ProjectResponse)
async def create_project(
    project: ProjectCreate,
    db: AsyncSession = Depends(get_db)
):
    """创建新项目"""
    new_project = Project(
        title=project.title,
        topic=project.topic,
        format_template=project.format_template
    )
    db.add(new_project)
    await db.commit()
    await db.refresh(new_project)
    logger.info(f"创建项目: {new_project.id}")
    return new_project

@router.get("", response_model=ProjectListResponse)
async def list_projects(db: AsyncSession = Depends(get_db)):
    """获取项目列表"""
    result = await db.execute(select(Project).order_by(Project.updated_at.desc()))
    projects = result.scalars().all()
    return ProjectListResponse(
        data=[ProjectResponse.model_validate(p) for p in projects],
        total=len(projects)
    )

@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, db: AsyncSession = Depends(get_db)):
    """获取项目详情"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")
    return project

@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    update: ProjectUpdate,
    db: AsyncSession = Depends(get_db)
):
    """更新项目"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    update_data = update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(project, key, value)

    await db.commit()
    await db.refresh(project)
    logger.info(f"更新项目: {project_id}")
    return project

@router.delete("/{project_id}", response_model=SuccessResponse)
async def delete_project(project_id: str, db: AsyncSession = Depends(get_db)):
    """删除项目"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    await db.delete(project)
    await db.commit()
    logger.info(f"删除项目: {project_id}")
    return SuccessResponse(success=True, message="项目删除成功")
