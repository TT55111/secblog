"""
文献数据模型 - 定义文献记录的数据结构
"""
from sqlalchemy import Column, String, DateTime, Text, Integer, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from database import Base

class Literature(Base):
    """文献记录数据模型"""
    __tablename__ = "literature"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    project_id = Column(String(36), ForeignKey("projects.id"), nullable=False)
    title = Column(String(1000), nullable=False)
    authors = Column(Text, nullable=False)
    abstract = Column(Text)
    publication_year = Column(Integer)
    citation_key = Column(String(100))
    source = Column(String(50))
    doi = Column(String(200))
    url = Column(String(500))
    cached_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="literature")
