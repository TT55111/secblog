# 学术论文写作助手

一款面向本科生的智能学术论文写作辅助工具，支持文献检索、大纲规划、内容撰写和格式校验。

## 功能特性

- 📚 **文献检索**: 接入arXiv、Semantic Scholar、Crossref公开数据库
- 📋 **大纲规划**: 根据主题和文献自动生成论文大纲
- ✍️ **内容撰写**: 逐章节生成论文内容，支持RAG增强
- ✅ **格式校验**: 支持10+种学术论文格式
- 🤖 **多模型支持**: OpenAI、Claude、文心一言等

## 快速开始

### 环境要求

- Python 3.11+
- Windows 10/11

### 安装运行

1. 安装依赖：
```bash
cd backend
pip install -r requirements.txt

cd ../frontend
pip install -r requirements.txt
```

2. 启动后端服务：
```bash
cd backend/src
python -m uvicorn main:app --reload
```

3. 启动前端服务：
```bash
cd frontend
streamlit run app.py
```

4. 打开浏览器访问 http://localhost:8501

### 配置API Key

首次使用需要在设置页面配置AI模型的API Key。

## 支持的格式

- GB/T 7714-2015（中国国家标准）
- IEEE Conference
- IEEE Transaction
- ACM Conference
- APA 7th
- MLA 9th
- Chicago
- Springer
- Elsevier

## 技术栈

- 后端: FastAPI
- 前端: Streamlit
- AI: LiteLLM
- 数据库: SQLite

## 项目结构

```
paper-writing-assistant/
├── backend/           # FastAPI后端
│   ├── src/
│   │   ├── agents/    # 4个核心Agent
│   │   ├── routers/   # API路由
│   │   ├── models/    # 数据模型
│   │   └── services/  # LLM服务
│   └── templates/     # 格式模板
├── frontend/          # Streamlit前端
│   ├── pages/         # 6个页面
│   └── services/      # API客户端
└── logs/              # 日志目录
```

## 许可证

MIT License
