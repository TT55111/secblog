"""
日志模块 - 配置应用日志系统
使用loguru库提供高性能日志功能
"""
from loguru import logger
from pathlib import Path
from config import LOGS_DIR

LOGS_DIR.mkdir(parents=True, exist_ok=True)

logger.add(
    LOGS_DIR / "app.log",
    rotation="10 MB",
    retention="7 days",
    level="INFO",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} - {message}",
    encoding="utf-8"
)

logger.add(
    LOGS_DIR / "error.log",
    rotation="10 MB",
    retention="7 days",
    level="ERROR",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} - {message}",
    encoding="utf-8"
)

logger.add(
    LOGS_DIR / "agent.log",
    rotation="10 MB",
    retention="7 days",
    level="DEBUG",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} - {message}",
    encoding="utf-8"
)

def get_logger(name: str = __name__):
    """
    获取带有指定名称的logger实例

    Args:
        name: logger名称，默认为模块名称

    Returns:
        logger: 配置好的logger实例
    """
    return logger.bind(name=name)
