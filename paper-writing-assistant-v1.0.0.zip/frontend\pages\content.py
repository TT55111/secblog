"""
内容撰写页面 - 处理章节内容生成和编辑
"""
import streamlit as st
import requests

def main():
    """内容撰写页面主函数"""
    st.header("内容撰写")

    if not st.session_state.get("current_project"):
        st.warning("请先在「项目管理」中选择一个项目")
        return

    project = st.session_state.current_project

    try:
        outline_response = requests.get(
            f"{st.session_state.api_base_url}/api/projects/{project['id']}/outline"
        )
        if outline_response.status_code != 200:
            st.warning("请先在大纲规划中生成大纲")
            return

        outline = outline_response.json()
        sections = outline.get("structure", {}).get("sections", [])

        section_options = {s["id"]: s["title"] for s in sections}
        selected_section = st.selectbox("选择章节", options=list(section_options.keys()),
                                       format_func=lambda x: f"{x}. {section_options[x]}")

        content_response = requests.get(
            f"{st.session_state.api_base_url}/api/projects/{project['id']}/content"
        )
        existing_content = {}
        if content_response.status_code == 200:
            for c in content_response.json():
                existing_content[c["section_id"]] = c

        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("🤖 AI生成内容", type="primary"):
                with st.spinner("正在生成内容..."):
                    try:
                        gen_response = requests.post(
                            f"{st.session_state.api_base_url}/api/projects/{project['id']}/content/generate",
                            json={"section_id": selected_section}
                        )
                        if gen_response.status_code == 200:
                            st.success("内容生成成功！")
                            st.rerun()
                        else:
                            st.error(f"生成失败: {gen_response.text}")
                    except Exception as e:
                        st.error(f"连接错误: {str(e)}")

        current_content = existing_content.get(selected_section, {}).get("content", "")
        edited_content = st.text_area("章节内容", value=current_content, height=400)

        if st.button("💾 保存内容"):
            try:
                update_response = requests.put(
                    f"{st.session_state.api_base_url}/api/projects/{project['id']}/content/{selected_section}",
                    json={"content": edited_content}
                )
                if update_response.status_code == 200:
                    st.success("内容保存成功！")
                else:
                    st.error(f"保存失败: {update_response.text}")
            except Exception as e:
                st.error(f"连接错误: {str(e)}")

    except Exception as e:
        st.error(f"连接错误: {str(e)}")

if __name__ == "__main__":
    main()
