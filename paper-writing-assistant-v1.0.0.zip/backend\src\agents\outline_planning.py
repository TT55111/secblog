"""
大纲规划Agent - 根据论文主题和文献生成论文大纲
支持研究论文、综述论文、实验报告等类型
"""
from typing import List, Optional
import json
import re

from base import BaseAgent
from schemas.api import LiteratureResponse, OutlineSection, OutlineStructure
from services.llm_service import llm_service
from utils.exceptions import OutlineGenerationError

PAPER_TYPES = {
    "research": "研究论文",
    "survey": "综述论文",
    "experiment": "实验报告"
}

OUTLINE_TEMPLATES = {
    "research": [
        {"id": "1", "title": "摘要", "level": 1, "word_count_target": 300},
        {"id": "2", "title": "关键词", "level": 1, "word_count_target": 50},
        {"id": "3", "title": "1 引言", "level": 1, "word_count_target": 800},
        {"id": "3.1", "title": "1.1 研究背景", "level": 2, "word_count_target": 400},
        {"id": "3.2", "title": "1.2 研究意义", "level": 2, "word_count_target": 400},
        {"id": "4", "title": "2 相关工作", "level": 1, "word_count_target": 1500},
        {"id": "5", "title": "3 研究方法", "level": 1, "word_count_target": 2000},
        {"id": "5.1", "title": "3.1 数据来源", "level": 2, "word_count_target": 500},
        {"id": "5.2", "title": "3.2 研究框架", "level": 2, "word_count_target": 1000},
        {"id": "5.3", "title": "3.3 实验设计", "level": 2, "word_count_target": 500},
        {"id": "6", "title": "4 实验结果与分析", "level": 1, "word_count_target": 2500},
        {"id": "6.1", "title": "4.1 实验环境", "level": 2, "word_count_target": 300},
        {"id": "6.2", "title": "4.2 结果分析", "level": 2, "word_count_target": 1500},
        {"id": "6.3", "title": "4.3 对比实验", "level": 2, "word_count_target": 700},
        {"id": "7", "title": "5 结论与展望", "level": 1, "word_count_target": 800},
        {"id": "7.1", "title": "5.1 研究结论", "level": 2, "word_count_target": 400},
        {"id": "7.2", "title": "5.2 未来工作", "level": 2, "word_count_target": 400},
        {"id": "8", "title": "参考文献", "level": 1, "word_count_target": 0},
    ],
    "survey": [
        {"id": "1", "title": "摘要", "level": 1, "word_count_target": 400},
        {"id": "2", "title": "关键词", "level": 1, "word_count_target": 50},
        {"id": "3", "title": "1 引言", "level": 1, "word_count_target": 1000},
        {"id": "4", "title": "2 研究现状", "level": 1, "word_count_target": 3000},
        {"id": "4.1", "title": "2.1 核心概念定义", "level": 2, "word_count_target": 800},
        {"id": "4.2", "title": "2.2 技术路线分析", "level": 2, "word_count_target": 1200},
        {"id": "4.3", "title": "2.3 主要方法对比", "level": 2, "word_count_target": 1000},
        {"id": "5", "title": "3 发展趋势", "level": 1, "word_count_target": 1500},
        {"id": "6", "title": "4 结论与展望", "level": 1, "word_count_target": 800},
        {"id": "7", "title": "参考文献", "level": 1, "word_count_target": 0},
    ],
    "experiment": [
        {"id": "1", "title": "摘要", "level": 1, "word_count_target": 350},
        {"id": "2", "title": "关键词", "level": 1, "word_count_target": 50},
        {"id": "3", "title": "1 实验目的", "level": 1, "word_count_target": 500},
        {"id": "4", "title": "2 实验原理", "level": 1, "word_count_target": 1000},
        {"id": "5", "title": "3 实验材料与方法", "level": 1, "word_count_target": 1500},
        {"id": "5.1", "title": "3.1 实验材料", "level": 2, "word_count_target": 500},
        {"id": "5.2", "title": "3.2 实验步骤", "level": 2, "word_count_target": 1000},
        {"id": "6", "title": "4 实验结果", "level": 1, "word_count_target": 2000},
        {"id": "6.1", "title": "4.1 数据记录", "level": 2, "word_count_target": 800},
        {"id": "6.2", "title": "4.2 结果分析", "level": 2, "word_count_target": 1200},
        {"id": "7", "title": "5 讨论", "level": 1, "word_count_target": 1000},
        {"id": "8", "title": "6 结论", "level": 1, "word_count_target": 500},
        {"id": "9", "title": "参考文献", "level": 1, "word_count_target": 0},
    ]
}

class OutlinePlanningAgent(BaseAgent):
    """
    大纲规划Agent
    根据论文主题和相关文献生成论文大纲
    """

    def __init__(self):
        super().__init__("OutlinePlanning")
        self.llm = llm_service

    async def execute(
        self,
        topic: str,
        literature: List[LiteratureResponse],
        paper_type: Optional[str] = None
    ) -> OutlineStructure:
        """
        执行大纲生成

        Args:
            topic: 论文主题
            literature: 相关文献列表
            paper_type: 论文类型，默认自动检测

        Returns:
            OutlineStructure: 生成的大纲结构
        """
        self.log_info(f"开始生成大纲，主题: {topic}")

        if paper_type is None:
            paper_type = await self._analyze_paper_type(topic, literature)

        self.log_info(f"论文类型: {PAPER_TYPES.get(paper_type, '研究论文')}")

        if literature:
            outline = await self._generate_from_template(topic, paper_type, literature)
        else:
            outline = await self._generate_with_llm(topic, paper_type)

        self.log_info(f"大纲生成完成，共 {len(outline.sections)} 个章节")
        return outline

    async def _analyze_paper_type(
        self,
        topic: str,
        literature: List[LiteratureResponse]
    ) -> str:
        """
        分析论文类型

        Args:
            topic: 论文主题
            literature: 文献列表

        Returns:
            str: 论文类型 (research/survey/experiment)
        """
        system_prompt = """你是一个学术论文写作专家。根据用户输入的论文主题和相关文献，判断这是一篇什么类型的论文。

论文类型包括：
- research: 研究论文（提出新方法、做实验验证）
- survey: 综述论文（总结分析现有研究）
- experiment: 实验报告（描述实验过程和结果）

请直接输出类型名称，不要解释。"""

        literature_summary = "\n".join([
            f"- {lit.title} ({lit.publication_year})" for lit in literature[:10]
        ]) if literature else "无相关文献"

        prompt = f"""论文主题：{topic}

相关文献：
{literature_summary}

请判断这篇论文的类型，直接输出：research、survey 或 experiment"""

        try:
            result, _ = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.3,
                max_tokens=50
            )
            result = result.strip().lower()
            if result in PAPER_TYPES:
                return result
            return "research"
        except Exception as e:
            self.log_error(f"论文类型分析失败: {str(e)}")
            return "research"

    async def _generate_from_template(
        self,
        topic: str,
        paper_type: str,
        literature: List[LiteratureResponse]
    ) -> OutlineStructure:
        """
        从模板生成大纲（当有文献时使用）

        Args:
            topic: 论文主题
            paper_type: 论文类型
            literature: 文献列表

        Returns:
            OutlineStructure: 生成的大纲
        """
        template = OUTLINE_TEMPLATES.get(paper_type, OUTLINE_TEMPLATES["research"])

        literature_summary = "\n".join([
            f"- {lit.title} - {lit.authors} ({lit.publication_year})"
            for lit in literature[:10]
        ])

        system_prompt = """你是一个学术论文写作专家。根据给定的论文主题和相关文献，生成论文大纲。

请以JSON格式输出章节描述，修改每个章节的description字段，说明该章节应该包含什么内容。
确保章节内容与论文主题高度相关。"""

        sections_json = json.dumps(template, ensure_ascii=False, indent=2)

        prompt = f"""论文主题：{topic}

相关文献：
{literature_summary}

论文类型：{PAPER_TYPES.get(paper_type, '研究论文')}

当前大纲模板：
{sections_json}

请根据论文主题和相关文献，更新每个章节的description字段，使其内容更贴合主题。
只修改description字段，其他字段保持不变。直接输出JSON，不要解释。"""

        try:
            result, _ = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.5,
                max_tokens=3000
            )

            json_match = re.search(r'\[.*\]|\{.*\}', result, re.DOTALL)
            if json_match:
                sections_data = json.loads(json_match.group())
            else:
                sections_data = template

            sections = []
            for sec in sections_data:
                sections.append(OutlineSection(
                    id=sec["id"],
                    title=sec["title"],
                    level=sec["level"],
                    description=sec.get("description"),
                    word_count_target=sec.get("word_count_target"),
                    children=[]
                ))

            total_words = sum(sec.word_count_target or 0 for sec in sections)

            return OutlineStructure(
                paper_type=paper_type,
                total_words=total_words,
                sections=sections
            )
        except Exception as e:
            self.log_error(f"模板大纲生成失败: {str(e)}")
            return OutlineStructure(
                paper_type=paper_type,
                total_words=sum(sec.get("word_count_target", 0) for sec in template),
                sections=[OutlineSection(**sec) for sec in template]
            )

    async def _generate_with_llm(
        self,
        topic: str,
        paper_type: str
    ) -> OutlineStructure:
        """
        使用LLM生成大纲（当无文献时使用）

        Args:
            topic: 论文主题
            paper_type: 论文类型

        Returns:
            OutlineStructure: 生成的大纲
        """
        system_prompt = """你是一个学术论文写作专家。根据论文主题生成详细的论文大纲。

请以JSON格式输出，格式如下：
{
  "sections": [
    {
      "id": "章节编号，如1, 2, 2.1等",
      "title": "章节标题",
      "level": "层级（1为主标题，2为副标题）",
      "description": "该章节应该包含的内容描述",
      "word_count_target": "建议字数"
    }
  ]
}

确保大纲结构完整，包含摘要、关键词、引言、正文、结论、参考文献等部分。"""

        prompt = f"""请为以下主题的论文生成详细大纲：

论文主题：{topic}
论文类型：{PAPER_TYPES.get(paper_type, '研究论文')}

请生成完整的论文大纲，包含所有必要的章节。直接输出JSON，不要解释。"""

        try:
            result, _ = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.5,
                max_tokens=3000
            )

            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                sections = [OutlineSection(**s) for s in data.get("sections", [])]
            else:
                template = OUTLINE_TEMPLATES.get(paper_type, OUTLINE_TEMPLATES["research"])
                sections = [OutlineSection(**sec) for sec in template]

            total_words = sum(sec.word_count_target or 0 for sec in sections)

            return OutlineStructure(
                paper_type=paper_type,
                total_words=total_words,
                sections=sections
            )
        except Exception as e:
            self.log_error(f"LLM大纲生成失败: {str(e)}")
            raise OutlineGenerationError(str(e))
