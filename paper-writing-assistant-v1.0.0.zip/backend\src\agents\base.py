"""
Agent基类模块 - 定义所有Agent的抽象基类
提供日志记录和通用接口
"""
from abc import ABC, abstractmethod
from typing import Any, Dict
from utils.logger import get_logger

class BaseAgent(ABC):
    """
    Agent抽象基类
    所有具体Agent都应继承此类并实现execute方法
    """

    def __init__(self, name: str):
        """
        初始化Agent

        Args:
            name: Agent名称，用于日志记录
        """
        self.name = name
        self.logger = get_logger(f"agent.{name}")

    @abstractmethod
    async def execute(self, *args, **kwargs) -> Any:
        """
        执行Agent的核心逻辑
        子类必须实现此方法

        Args:
            *args: 位置参数
            **kwargs: 关键字参数

        Returns:
            Any: 执行结果
        """
        pass

    def log_info(self, message: str):
        """记录信息日志"""
        self.logger.info(f"[{self.name}] {message}")

    def log_error(self, message: str):
        """记录错误日志"""
        self.logger.error(f"[{self.name}] {message}")

    def log_debug(self, message: str):
        """记录调试日志"""
        self.logger.debug(f"[{self.name}] {message}")
