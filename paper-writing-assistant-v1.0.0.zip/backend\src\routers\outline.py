"""
大纲规划路由 - 处理大纲生成和更新
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from database import get_db
from models.project import Project
from models.outline import Outline
from models.literature import Literature
from schemas.api import OutlineResponse, OutlineStructure
from agents.outline_planning import OutlinePlanningAgent
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects/{project_id}/outline", tags=["大纲规划"])
logger = get_logger("router.outline")
planning_agent = OutlinePlanningAgent()

@router.post("/generate", response_model=OutlineResponse)
async def generate_outline(
    project_id: str,
    paper_type: str = None,
    db: AsyncSession = Depends(get_db)
):
    """生成大纲"""
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    lit_result = await db.execute(
        select(Literature).where(Literature.project_id == project_id)
    )
    literature = lit_result.scalars().all()

    outline_structure = await planning_agent.execute(
        topic=project.topic,
        literature=literature,
        paper_type=paper_type
    )

    outline = Outline(
        project_id=project_id,
        structure=outline_structure.model_dump(),
        user_modified=False
    )

    existing = await db.execute(
        select(Outline).where(Outline.project_id == project_id)
    )
    existing_outline = existing.scalar_one_or_none()
    if existing_outline:
        for key, value in outline.__dict__.items():
            setattr(existing_outline, key, value)
    else:
        db.add(outline)

    project.status = ProjectStatus.OUTLINE_COMPLETE
    await db.commit()

    await db.refresh(outline)
    return outline

@router.get("", response_model=OutlineResponse)
async def get_outline(project_id: str, db: AsyncSession = Depends(get_db)):
    """获取大纲"""
    result = await db.execute(
        select(Outline).where(Outline.project_id == project_id)
    )
    outline = result.scalar_one_or_none()
    if not outline:
        raise HTTPException(status_code=404, detail="大纲不存在")
    return outline

@router.put("", response_model=OutlineResponse)
async def update_outline(
    project_id: str,
    structure: OutlineStructure,
    db: AsyncSession = Depends(get_db)
):
    """更新大纲"""
    result = await db.execute(
        select(Outline).where(Outline.project_id == project_id)
    )
    outline = result.scalar_one_or_none()
    if not outline:
        raise HTTPException(status_code=404, detail="大纲不存在")

    outline.structure = structure.model_dump()
    outline.user_modified = True
    await db.commit()
    await db.refresh(outline)
    return outline
