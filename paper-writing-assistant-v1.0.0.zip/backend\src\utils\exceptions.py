"""
自定义异常模块 - 定义应用中使用的所有自定义异常类型
"""
from typing import Optional, Any

class BaseAppException(Exception):
    """应用异常基类，所有自定义异常都应继承此类"""

    def __init__(
        self,
        code: str,
        message: str,
        details: Optional[str] = None,
        recoverable: bool = True,
        suggestion: Optional[str] = None
    ):
        self.code = code
        self.message = message
        self.details = details
        self.recoverable = recoverable
        self.suggestion = suggestion
        super().__init__(message)

    def to_dict(self) -> dict[str, Any]:
        """将异常转换为字典格式，用于API响应"""
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
            "recoverable": self.recoverable,
            "suggestion": self.suggestion
        }

class APIKeyMissingError(BaseAppException):
    """API Key未配置异常"""
    def __init__(self, model: str):
        super().__init__(
            code="API_KEY_MISSING",
            message=f"未配置 {model} 的API Key",
            recoverable=False,
            suggestion="请到设置页面配置API Key"
        )

class APIQuotaExceededError(BaseAppException):
    """API配额超限异常"""
    def __init__(self, model: str):
        super().__init__(
            code="API_QUOTA_EXCEEDED",
            message=f"{model} API配额超限",
            recoverable=True,
            suggestion="请稍后重试，或切换到其他模型"
        )

class LiteratureSearchError(BaseAppException):
    """文献检索异常"""
    def __init__(self, source: str, details: str):
        super().__init__(
            code="LITERATURE_SEARCH_FAILED",
            message=f"从{source}检索文献失败",
            details=details,
            recoverable=True,
            suggestion="请稍后重试，或尝试其他数据源"
        )

class OutlineGenerationError(BaseAppException):
    """大纲生成异常"""
    def __init__(self, details: str):
        super().__init__(
            code="OUTLINE_GENERATION_FAILED",
            message="生成论文大纲失败",
            details=details,
            recoverable=True,
            suggestion="请稍后重试，或手动编辑大纲"
        )

class ContentGenerationError(BaseAppException):
    """内容生成异常"""
    def __init__(self, details: str):
        super().__init__(
            code="CONTENT_GENERATION_FAILED",
            message="生成论文内容失败",
            details=details,
            recoverable=True,
            suggestion="请稍后重试，或分段生成内容"
        )

class FormatValidationError(BaseAppException):
    """格式校验异常"""
    def __init__(self, details: str):
        super().__init__(
            code="FORMAT_VALIDATION_FAILED",
            message="格式校验失败",
            details=details,
            recoverable=True,
            suggestion="请查看错误列表并修复"
        )

class ExportError(BaseAppException):
    """导出异常"""
    def __init__(self, details: str):
        super().__init__(
            code="EXPORT_FAILED",
            message="导出论文失败",
            details=details,
            recoverable=True,
            suggestion="请检查文件权限或格式"
        )
