"""
项目管理页面 - 处理论文项目的CRUD操作
"""
import streamlit as st
import requests

def main():
    """项目管理页面主函数"""
    st.header("项目管理")

    col1, col2 = st.columns([3, 1])
    with col1:
        if st.button("🔄 刷新项目列表"):
            st.rerun()

    with col2:
        if st.button("➕ 新建项目", type="primary"):
            st.session_state.show_new_project = True

    if "show_new_project" not in st.session_state:
        st.session_state.show_new_project = False

    if st.session_state.show_new_project:
        with st.form("new_project_form"):
            st.subheader("新建论文项目")
            title = st.text_input("论文标题", placeholder="请输入论文标题")
            topic = st.text_input("研究主题/关键词", placeholder="请输入研究主题或关键词")
            format_template = st.selectbox(
                "论文格式模板",
                ["gb_t_7714", "ieee_conference", "ieee_transaction", "acm_conference",
                 "apa_7", "mla_9", "chicago", "springer", "elsevier"],
                format_func=lambda x: {
                    "gb_t_7714": "GB/T 7714-2015（中国国家标准）",
                    "ieee_conference": "IEEE Conference",
                    "ieee_transaction": "IEEE Transaction",
                    "acm_conference": "ACM Conference",
                    "apa_7": "APA 7th",
                    "mla_9": "MLA 9th",
                    "chicago": "Chicago",
                    "springer": "Springer",
                    "elsevier": "Elsevier"
                }.get(x, x)
            )

            col_submit, col_cancel = st.columns(2)
            with col_submit:
                submitted = st.form_submit_button("创建项目", type="primary")
            with col_cancel:
                if st.form_submit_button("取消"):
                    st.session_state.show_new_project = False
                    st.rerun()

            if submitted and title and topic:
                try:
                    response = requests.post(
                        f"{st.session_state.api_base_url}/api/projects",
                        json={"title": title, "topic": topic, "format_template": format_template}
                    )
                    if response.status_code == 200:
                        st.success("项目创建成功！")
                        st.session_state.show_new_project = False
                        st.rerun()
                    else:
                        st.error(f"创建失败: {response.text}")
                except Exception as e:
                    st.error(f"连接错误: {str(e)}")

    st.divider()

    try:
        response = requests.get(f"{st.session_state.api_base_url}/api/projects")
        if response.status_code == 200:
            data = response.json()
            projects = data.get("data", [])

            if not projects:
                st.info("暂无项目，请点击「新建项目」创建一个")
            else:
                for project in projects:
                    with st.container():
                        col1, col2, col3 = st.columns([4, 1, 1])
                        with col1:
                            st.subheader(f"📄 {project['title']}")
                            st.caption(f"主题: {project['topic']}")
                            st.caption(f"创建时间: {project['created_at'][:10]}")
                            status_map = {
                                "draft": "📝 草稿",
                                "outline_complete": "📋 大纲完成",
                                "draft_complete": "📄 初稿完成",
                                "final": "✅ 终稿"
                            }
                            st.write(status_map.get(project['status'], project['status']))
                        with col2:
                            if st.button("打开", key=f"open_{project['id']}"):
                                st.session_state.current_project = project
                                st.rerun()
                        with col3:
                            if st.button("🗑️", key=f"delete_{project['id']}"):
                                requests.delete(
                                    f"{st.session_state.api_base_url}/api/projects/{project['id']}"
                                )
                                st.rerun()
                        st.divider()
        else:
            st.error("获取项目列表失败")
    except Exception as e:
        st.error(f"连接错误: {str(e)}")

if __name__ == "__main__":
    main()
