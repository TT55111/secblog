# 学术论文写作助手 - Windows打包脚本
# 使用PyInstaller打包为可执行文件

param(
    [string]$Version = "1.0.0"
)

$ErrorActionPreference = "Stop"

$PROJECT_ROOT = Split-Path -Parent $PSScriptRoot
$BACKEND_DIR = Join-Path $PROJECT_ROOT "backend"
$FRONTEND_DIR = Join-Path $PROJECT_ROOT "frontend"
$BUILD_DIR = Join-Path $PROJECT_ROOT "build"
$RELEASE_DIR = Join-Path $PROJECT_ROOT "release"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "学术论文写作助手 - 打包脚本 v$Version" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

Write-Host "`n[1/6] 清理旧构建..." -ForegroundColor Yellow
if (Test-Path $BUILD_DIR) { Remove-Item -Recurse -Force $BUILD_DIR }
if (Test-Path $RELEASE_DIR) { Remove-Item -Recurse -Force $RELEASE_DIR }
New-Item -ItemType Directory -Path $BUILD_DIR -Force | Out-Null
New-Item -ItemType Directory -Path $RELEASE_DIR -Force | Out-Null

Write-Host "`n[2/6] 安装后端依赖..." -ForegroundColor Yellow
Set-Location $BACKEND_DIR
pip install -r requirements.txt

Write-Host "`n[3/6] 安装前端依赖..." -ForegroundColor Yellow
Set-Location $FRONTEND_DIR
pip install -r requirements.txt

Write-Host "`n[4/6] 安装PyInstaller..." -ForegroundColor Yellow
pip install pyinstaller

Write-Host "`n[5/6] 打包应用..." -ForegroundColor Yellow

Write-Host "  - 打包后端服务..." -ForegroundColor Cyan
$BACKEND_BUILD = Join-Path $BUILD_DIR "backend"
New-Item -ItemType Directory -Path $BACKEND_BUILD -Force | Out-Null
Set-Location $BACKEND_DIR
pyinstaller --onefile --name paper_assistant_backend `
    --add-data "templates;templates" `
    --hidden-import "uvicorn" `
    --hidden-import "fastapi" `
    --hidden-import "sqlalchemy" `
    --hidden-import "aiosqlite" `
    --hidden-import "litellm" `
    --hidden-import "httpx" `
    src/main.py

Move-Item (Join-Path $BACKEND_DIR "dist\paper_assistant_backend.exe") $BACKEND_BUILD -Force

Write-Host "  - 打包前端服务..." -ForegroundColor Cyan
$FRONTEND_BUILD = Join-Path $BUILD_DIR "frontend"
New-Item -ItemType Directory -Path $FRONTEND_BUILD -Force | Out-Null
Set-Location $FRONTEND_DIR
pyinstaller --onefile --name paper_assistant_frontend app.py

Move-Item (Join-Path $FRONTEND_DIR "dist\paper_assistant_frontend.exe") $FRONTEND_BUILD -Force

Write-Host "`n[6/6] 创建发布包..." -ForegroundColor Yellow

$START_SCRIPT = @"
@echo off
title 学术论文写作助手
echo ========================================
echo 学术论文写作助手 v$Version
echo ========================================
echo.
echo 正在启动服务...
echo.

REM 启动后端服务
start "后端服务" cmd /k "cd /d %~dp0backend && paper_assistant_backend.exe"

REM 等待后端启动
timeout /t 3 /nobreak > nul

REM 启动前端服务
start "" %~dp0frontend\paper_assistant_frontend.exe

echo.
echo 服务已启动！
echo 后端API: http://localhost:8000
echo 前端界面: http://localhost:8501
echo.
echo 按任意键关闭此窗口（服务将继续在后台运行）
pause > nul
"@

$START_SCRIPT | Out-File -FilePath (Join-Path $BUILD_DIR "启动助手.bat") -Encoding UTF8

$README_CONTENT = @"
# 学术论文写作助手 v$Version

## 使用说明

1. 双击运行 `启动助手.bat`
2. 系统将自动启动后端服务和前端界面
3. 打开浏览器访问 http://localhost:8501
4. 首次使用需要在设置页面配置AI模型的API Key

## 功能特性

- 📚 文献检索: 接入arXiv、Semantic Scholar、Crossref
- 📋 大纲规划: 根据主题和文献自动生成论文大纲
- ✍️ 内容撰写: 逐章节生成论文内容
- ✅ 格式校验: 支持多种学术论文格式
- 🤖 多模型支持: OpenAI、Claude、文心一言等

## 系统要求

- Windows 10/11
- 网络连接（用于AI模型调用）

## 配置说明

如需配置API Key，请编辑 `.env` 文件：
```
OPENAI_API_KEY=your_api_key_here
```

## 技术支持

如有问题，请查看日志文件。
"@

$README_CONTENT | Out-File -FilePath (Join-Path $BUILD_DIR "README.md") -Encoding UTF8

Copy-Item (Join-Path $PROJECT_ROOT ".env.example") (Join-Path $BUILD_DIR ".env")

Write-Host "`n正在创建压缩包..." -ForegroundColor Yellow
$ZIP_NAME = "paper-writing-assistant-v$Version.zip"
Compress-Archive -Path "$BUILD_DIR\*" -DestinationPath (Join-Path $RELEASE_DIR $ZIP_NAME) -Force

Set-Location $PROJECT_ROOT

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "✅ 构建完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "发布包: $RELEASE_DIR\$ZIP_NAME" -ForegroundColor Cyan
Write-Host "直接运行包: $BUILD_DIR\启动助手.bat" -ForegroundColor Cyan
