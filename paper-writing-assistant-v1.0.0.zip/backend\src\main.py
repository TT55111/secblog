"""
FastAPI主应用 - 学术论文写作助手后端服务入口
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from database import init_db
from routers import projects, literature, outline, content, validation, export
from config import settings
from utils.logger import logger
from utils.exceptions import BaseAppException

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    logger.info("应用启动中...")
    await init_db()
    logger.info("数据库初始化完成")
    yield
    logger.info("应用关闭")

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.exception_handler(BaseAppException)
async def app_exception_handler(request: Request, exc: BaseAppException):
    """应用异常处理器"""
    return JSONResponse(
        status_code=400 if exc.recoverable else 500,
        content={
            "success": False,
            "error": exc.to_dict()
        }
    )

@app.get("/")
async def root():
    """根路径"""
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running"
    }

@app.get("/health")
async def health():
    """健康检查"""
    return {"status": "healthy"}

@app.get("/api/templates")
async def list_templates():
    """获取可用模板列表"""
    from config import get_available_templates
    return {"templates": get_available_templates()}

@app.get("/api/config/models")
async def list_models():
    """获取可用模型列表"""
    return {
        "models": [
            {"id": "gpt-4", "name": "GPT-4", "provider": "OpenAI"},
            {"id": "gpt-3.5-turbo", "name": "GPT-3.5", "provider": "OpenAI"},
            {"id": "claude-3-sonnet", "name": "Claude 3 Sonnet", "provider": "Anthropic"},
            {"id": "claude-3-haiku", "name": "Claude 3 Haiku", "provider": "Anthropic"},
            {"id": "qwen-turbo", "name": "通义千问Turbo", "provider": "阿里云"},
            {"id": "ernie-4", "name": "文心一言4", "provider": "百度"},
        ],
        "current": settings.default_model
    }

app.include_router(projects.router)
app.include_router(literature.router)
app.include_router(outline.router)
app.include_router(content.router)
app.include_router(validation.router)
app.include_router(export.router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
