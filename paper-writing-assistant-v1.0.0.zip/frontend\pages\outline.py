"""
大纲规划页面 - 处理论文大纲生成和编辑
"""
import streamlit as st
import requests

def main():
    """大纲规划页面主函数"""
    st.header("大纲规划")

    if not st.session_state.get("current_project"):
        st.warning("请先在「项目管理」中选择一个项目")
        return

    project = st.session_state.current_project

    col1, col2 = st.columns([1, 3])
    with col1:
        if st.button("🤖 AI生成大纲", type="primary"):
            with st.spinner("正在生成大纲..."):
                try:
                    response = requests.post(
                        f"{st.session_state.api_base_url}/api/projects/{project['id']}/outline/generate"
                    )
                    if response.status_code == 200:
                        st.success("大纲生成成功！")
                        st.rerun()
                    else:
                        st.error(f"生成失败: {response.text}")
                except Exception as e:
                    st.error(f"连接错误: {str(e)}")

    try:
        response = requests.get(
            f"{st.session_state.api_base_url}/api/projects/{project['id']}/outline"
        )
        if response.status_code == 200:
            outline = response.json()
            structure = outline.get("structure", {})
            sections = structure.get("sections", [])

            st.subheader(f"论文大纲 - 预计 {structure.get('total_words', 0)} 字")

            for section in sections:
                level = section.get("level", 1)
                indent = "　" * (level - 1)
                word_target = section.get("word_count_target", 0)
                st.write(f"{indent}**{section['id']}. {section['title']}**" +
                        (f" (~{word_target}字)" if word_target else ""))
        else:
            st.info("暂无大纲，请点击「AI生成大纲」创建")
    except Exception as e:
        st.error(f"连接错误: {str(e)}")

if __name__ == "__main__":
    main()
