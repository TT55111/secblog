"""
设置页面 - 处理应用配置
"""
import streamlit as st
import os

def main():
    """设置页面主函数"""
    st.header("设置")

    st.subheader("API配置")
    api_base_url = st.text_input(
        "后端API地址",
        value=st.session_state.get("api_base_url", "http://localhost:8000")
    )

    if st.button("保存设置"):
        st.session_state.api_base_url = api_base_url
        st.success("设置已保存")

    st.divider()

    st.subheader("AI模型配置")
    try:
        response = requests.get(f"{st.session_state.api_base_url}/api/config/models", timeout=2)
        if response.status_code == 200:
            data = response.json()
            st.write("可用模型:")
            for model in data.get("models", []):
                st.write(f"- **{model['name']}** ({model['provider']})")
    except:
        st.info("请确保后端服务正在运行")

    st.divider()

    st.subheader("格式模板")
    try:
        response = requests.get(f"{st.session_state.api_base_url}/api/templates", timeout=2)
        if response.status_code == 200:
            data = response.json()
            for template in data.get("templates", []):
                st.write(f"- {template}")
    except:
        st.info("请确保后端服务正在运行")

if __name__ == "__main__":
    main()
