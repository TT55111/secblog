"""
内容撰写路由 - 处理章节内容生成和更新
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from database import get_db
from models.project import Project
from models.outline import Outline
from models.literature import Literature
from models.content import Content
from schemas.api import (
    ContentResponse, ContentGenerateRequest,
    ContentUpdate, OutlineSection
)
from agents.content_writing import ContentWritingAgent
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects/{project_id}/content", tags=["内容撰写"])
logger = get_logger("router.content")
writing_agent = ContentWritingAgent()

@router.post("/generate")
async def generate_content(
    project_id: str,
    request: ContentGenerateRequest,
    db: AsyncSession = Depends(get_db)
):
    """生成章节内容"""
    project = (await db.execute(select(Project).where(Project.id == project_id))).scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    outline = (await db.execute(select(Outline).where(Outline.project_id == project_id))).scalar_one_or_none()
    if not outline:
        raise HTTPException(status_code=404, detail="大纲不存在")

    outline_sections = [OutlineSection(**s) for s in outline.structure.get("sections", [])]
    section = next((s for s in outline_sections if s.id == request.section_id), None)
    if not section:
        raise HTTPException(status_code=404, detail="章节不存在")

    literature = (await db.execute(select(Literature).where(Literature.project_id == project_id))).scalars().all()

    previous = (await db.execute(
        select(Content).where(
            Content.project_id == project_id,
            Content.section_id < request.section_id
        ).order_by(Content.section_id.desc())
    )).scalar_one_or_none()

    content_text, token_count = await writing_agent.execute(
        section=section,
        outline=outline_sections,
        literature=literature,
        previous_content=previous.content if previous else None,
        context=request.context
    )

    existing = (await db.execute(
        select(Content).where(
            Content.project_id == project_id,
            Content.section_id == request.section_id
        )
    )).scalar_one_or_none()

    if existing:
        existing.content = content_text
        existing.ai_generated = True
        existing.token_count = token_count
    else:
        db.add(Content(
            project_id=project_id,
            section_id=request.section_id,
            section_title=section.title,
            content=content_text,
            ai_generated=True,
            token_count=token_count
        ))

    await db.commit()
    return {"success": True, "message": "内容生成成功", "token_count": token_count}

@router.get("")
async def get_content(project_id: str, db: AsyncSession = Depends(get_db)):
    """获取所有内容"""
    result = await db.execute(
        select(Content).where(Content.project_id == project_id)
    )
    return result.scalars().all()

@router.put("/{section_id}")
async def update_content(
    project_id: str,
    section_id: str,
    update: ContentUpdate,
    db: AsyncSession = Depends(get_db)
):
    """更新内容"""
    result = await db.execute(
        select(Content).where(
            Content.project_id == project_id,
            Content.section_id == section_id
        )
    )
    content = result.scalar_one_or_none()
    if not content:
        raise HTTPException(status_code=404, detail="内容不存在")

    content.content = update.content
    await db.commit()
    return {"success": True, "message": "内容更新成功"}
