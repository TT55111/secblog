"""
格式校验Agent - 校验论文格式是否符合选定模板
检查引用格式、章节结构、内容长度等
"""
import re
from typing import List, Optional

from base import BaseAgent
from schemas.api import (
    ValidationError, ValidationReport,
    ContentResponse, OutlineSection
)
from config import load_template

CITATION_PATTERNS = {
    "numeric": r'\[(\d+)\]',
    "author_year": r'\([A-Z][a-z]+(?: et al.)?,?\s*(\d{4})\)',
    "apa": r'\([[A-Z][a-z]+(?:,?\s*&\s*[A-Z][a-z]+)*,?\s*(\d{4})\)',
}

class FormatValidationAgent(BaseAgent):
    """
    格式校验Agent
    校验论文格式是否符合选定模板
    """

    def __init__(self):
        super().__init__("FormatValidation")

    async def execute(
        self,
        contents: List[ContentResponse],
        outline: List[OutlineSection],
        template_id: str
    ) -> ValidationReport:
        """
        执行格式校验

        Args:
            contents: 论文内容列表
            outline: 论文大纲
            template_id: 格式模板ID

        Returns:
            ValidationReport: 校验报告
        """
        self.log_info(f"开始校验格式，模板: {template_id}")

        try:
            template = load_template(template_id)
        except FileNotFoundError:
            template = load_template("gb_t_7714")

        errors = []
        warnings = []

        structure_errors = self._validate_structure(contents, outline)
        errors.extend(structure_errors)

        citation_style = template.get("citation_style", "numeric")
        citation_errors = self._validate_citations(contents, citation_style)
        errors.extend(citation_errors)

        length_errors, length_warnings = self._validate_length(contents, outline)
        errors.extend(length_errors)
        warnings.extend(length_warnings)

        missing_sections = self._check_missing_sections(contents, outline)
        if missing_sections:
            warnings.append(f"以下章节可能缺失: {', '.join(missing_sections)}")

        report = ValidationReport(
            total_errors=len(errors),
            errors=errors,
            warnings=warnings
        )

        self.log_info(f"格式校验完成，发现 {len(errors)} 个错误，{len(warnings)} 个警告")
        return report

    def _validate_structure(
        self,
        contents: List[ContentResponse],
        outline: List[OutlineSection]
    ) -> List[ValidationError]:
        """
        校验论文结构完整性

        Args:
            contents: 内容列表
            outline: 大纲

        Returns:
            List[ValidationError]: 结构错误列表
        """
        errors = []
        content_dict = {c.section_id: c for c in contents}
        outline_ids = {sec.id for sec in outline}

        required_main_sections = ["1", "3", "6", "7"]
        for req_id in required_main_sections:
            if req_id not in content_dict:
                errors.append(ValidationError(
                    section_id=req_id,
                    error_type="MISSING_SECTION",
                    message=f"缺少必需的章节: {req_id}",
                    suggestion="请确保主要章节完整"
                ))

        return errors

    def _validate_citations(
        self,
        contents: List[ContentResponse],
        citation_style: str
    ) -> List[ValidationError]:
        """
        校验引用格式

        Args:
            contents: 内容列表
            citation_style: 引用风格

        Returns:
            List[ValidationError]: 引用错误列表
        """
        errors = []
        pattern = CITATION_PATTERNS.get(citation_style, CITATION_PATTERNS["numeric"])

        for content in contents:
            if not content.content:
                continue

            citations = re.findall(pattern, content.content)
            if not citations and content.section_id.startswith(("2", "3", "4", "5")):
                errors.append(ValidationError(
                    section_id=content.section_id,
                    error_type="MISSING_CITATION",
                    message=f"章节 {content.section_id} 缺少引用",
                    suggestion="建议添加相关文献引用"
                ))

            if citation_style == "author_year":
                if re.search(r'\[\d+\]', content.content):
                    errors.append(ValidationError(
                        section_id=content.section_id,
                        error_type="INCORRECT_CITATION_STYLE",
                        message=f"章节 {content.section_id} 混用了数字引用格式",
                        location="citation",
                        suggestion="请使用作者年制引用格式，如 (Zhang, 2024)"
                    ))

        return errors

    def _validate_length(
        self,
        contents: List[ContentResponse],
        outline: List[OutlineSection]
    ) -> tuple[List[ValidationError], List[str]]:
        """
        校验章节内容长度

        Args:
            contents: 内容列表
            outline: 大纲

        Returns:
            tuple: (错误列表, 警告列表)
        """
        errors = []
        warnings = []
        outline_dict = {sec.id: sec for sec in outline}

        for content in contents:
            if not content.content or not content.section_id:
                continue

            target = outline_dict.get(content.section_id)
            if not target or not target.word_count_target:
                continue

            actual_words = len(content.content)
            target_words = target.word_count_target

            if actual_words < target_words * 0.5:
                errors.append(ValidationError(
                    section_id=content.section_id,
                    error_type="CONTENT_TOO_SHORT",
                    message=f"章节 {content.section_id} 内容过短（{actual_words}字 < {target_words}字）",
                    suggestion="请充实该章节内容"
                ))
            elif actual_words < target_words * 0.8:
                warnings.append(f"章节 {content.section_id} 内容偏少，建议达到 {target_words} 字")

        return errors, warnings

    def _check_missing_sections(
        self,
        contents: List[ContentResponse],
        outline: List[OutlineSection]
    ) -> List[str]:
        """
        检查缺失的章节

        Args:
            contents: 内容列表
            outline: 大纲

        Returns:
            List[str]: 缺失的章节ID列表
        """
        content_ids = {c.section_id for c in contents if c.content}
        outline_ids = {sec.id for sec in outline if sec.level == 1}

        return [sec_id for sec_id in outline_ids if sec_id not in content_ids]
