"""
内容撰写Agent - 根据大纲逐章节生成论文内容
支持RAG增强和自动引用插入
"""
from typing import List, Optional

from base import BaseAgent
from schemas.api import LiteratureResponse, OutlineSection
from services.llm_service import llm_service
from utils.exceptions import ContentGenerationError

class ContentWritingAgent(BaseAgent):
    """
    内容撰写Agent
    根据论文大纲和相关文献逐章节生成论文内容
    """

    def __init__(self):
        super().__init__("ContentWriting")
        self.llm = llm_service

    async def execute(
        self,
        section: OutlineSection,
        outline: List[OutlineSection],
        literature: List[LiteratureResponse],
        previous_content: Optional[str] = None,
        context: Optional[str] = None
    ) -> tuple[str, int]:
        """
        执行章节内容生成

        Args:
            section: 当前章节信息
            outline: 完整大纲
            literature: 文献列表
            previous_content: 前一章节内容（用于保持连贯性）
            context: 额外上下文

        Returns:
            tuple[str, int]: (生成的内容, 消耗的token数)
        """
        self.log_info(f"开始生成章节内容: {section.title}")

        system_prompt = """你是一个专业的学术论文写作专家。你的任务是帮助用户撰写高质量的学术论文内容。

写作要求：
1. 语言正式、专业，符合学术论文规范
2. 内容充实，论证充分
3. 适当引用相关文献
4. 逻辑清晰，层次分明
5. 避免空洞的套话，每句话都要有实质性内容"""

        prompt = self._build_prompt(section, outline, literature, previous_content, context)

        try:
            content, cost = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.7,
                max_tokens=2000
            )

            content_with_citations = self._add_citations(content, literature)

            self.log_info(f"章节 {section.title} 生成完成，字数约 {len(content)}")
            return content_with_citations, int(cost * 1000000)
        except Exception as e:
            self.log_error(f"章节内容生成失败: {str(e)}")
            raise ContentGenerationError(str(e))

    def _build_prompt(
        self,
        section: OutlineSection,
        outline: List[OutlineSection],
        literature: List[LiteratureResponse],
        previous_content: Optional[str],
        context: Optional[str]
    ) -> str:
        """
        构建生成内容的提示词

        Args:
            section: 当前章节
            outline: 完整大纲
            literature: 文献列表
            previous_content: 前文内容
            context: 额外上下文

        Returns:
            str: 构建好的提示词
        """
        outline_context = "\n".join([
            f"- {sec.title}" + (f": {sec.description}" if sec.description else "")
            for sec in outline
        ])

        literature_refs = "\n".join([
            f"- [{lit.citation_key}] {lit.title} - {lit.authors} ({lit.publication_year})"
            for lit in literature[:15] if lit.citation_key
        ])

        prompt_parts = []

        if section.description:
            prompt_parts.append(f"【章节要求】\n{section.description}")

        prompt_parts.append(f"【论文大纲】\n{outline_context}")

        if literature_refs:
            prompt_parts.append(f"【参考文献】\n{literature_refs}")

        if previous_content:
            prompt_parts.append(f"【前文内容摘要】\n{previous_content[-500:]}")

        if context:
            prompt_parts.append(f"【补充说明】\n{context}")

        word_target = section.word_count_target or 800
        prompt_parts.append(f"\n请撰写约 {word_target} 字的 {section.title} 内容。")

        return "\n\n".join(prompt_parts)

    def _add_citations(
        self,
        content: str,
        literature: List[LiteratureResponse]
    ) -> str:
        """
        在内容中自动添加引用

        Args:
            content: 原始内容
            literature: 文献列表

        Returns:
            str: 添加引用后的内容
        """
        if not literature:
            return content

        lit_dict = {lit.citation_key: lit for lit in literature if lit.citation_key}

        for citation_key, lit in lit_dict.items():
            if citation_key in content:
                continue

            keywords = lit.title.lower().split()[:5]
            for kw in keywords:
                if len(kw) > 4 and kw in content.lower():
                    content = content.replace(
                        kw, f"{kw} {citation_key}"
                    )
                    break

        return content

    async def generate_abstract(
        self,
        topic: str,
        outline: List[OutlineSection],
        literature: List[LiteratureResponse]
    ) -> tuple[str, int]:
        """
        生成论文摘要

        Args:
            topic: 论文主题
            outline: 论文大纲
            literature: 文献列表

        Returns:
            tuple[str, int]: (摘要内容, token消耗)
        """
        self.log_info("开始生成摘要")

        system_prompt = """你是一个专业的学术论文写作专家。请撰写简洁、准确的学术论文摘要。

摘要要求：
1. 长度约300字
2. 包含研究目的、方法、结果和结论
3. 突出研究的创新点和意义
4. 使用第三人称
5. 不引用参考文献"""

        literature_summary = "\n".join([
            f"- {lit.title}" for lit in literature[:5]
        ]) if literature else "无"

        prompt = f"""请为以下论文撰写摘要：

主题：{topic}

主要章节：
{chr(10).join([sec.title for sec in outline[:6]])}

相关研究：
{literature_summary}

请直接输出摘要内容，不要添加额外说明。"""

        try:
            abstract, cost = await self.llm.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.5,
                max_tokens=500
            )
            return abstract, int(cost * 1000000)
        except Exception as e:
            self.log_error(f"摘要生成失败: {str(e)}")
            raise ContentGenerationError(str(e))
