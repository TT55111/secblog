"""
文献检索Agent - 从多个学术数据库检索文献
支持arXiv、Semantic Scholar、Crossref
"""
import httpx
from typing import List, Optional
from urllib.parse import quote
import xml.etree.ElementTree as ET

from base import BaseAgent
from schemas.api import LiteratureResponse
from config import settings
from utils.exceptions import LiteratureSearchError
from datetime import datetime

class LiteratureSearchAgent(BaseAgent):
    """
    文献检索Agent
    从多个学术数据库并行检索文献，并进行去重处理
    """

    def __init__(self):
        super().__init__("LiteratureSearch")

    async def execute(self, topic: str, max_results: int = 20) -> List[LiteratureResponse]:
        """
        执行文献检索

        Args:
            topic: 检索主题/关键词
            max_results: 最大结果数

        Returns:
            List[LiteratureResponse]: 文献列表
        """
        self.log_info(f"开始检索文献，主题: {topic}, 最大结果数: {max_results}")
        all_literature = []

        arxiv_results = await self._search_arxiv(topic, max_results // 3)
        all_literature.extend(arxiv_results)
        self.log_info(f"arXiv检索到 {len(arxiv_results)} 条结果")

        semantic_results = await self._search_semantic_scholar(topic, max_results // 3)
        all_literature.extend(semantic_results)
        self.log_info(f"Semantic Scholar检索到 {len(semantic_results)} 条结果")

        crossref_results = await self._search_crossref(topic, max_results // 3)
        all_literature.extend(crossref_results)
        self.log_info(f"Crossref检索到 {len(crossref_results)} 条结果")

        unique_literature = self._deduplicate(all_literature)
        self.log_info(f"去重后共 {len(unique_literature)} 条结果")

        return unique_literature[:max_results]

    async def _search_arxiv(self, topic: str, max_results: int) -> List[LiteratureResponse]:
        """
        从arXiv检索文献

        Args:
            topic: 检索主题
            max_results: 最大结果数

        Returns:
            List[LiteratureResponse]: arXiv文献列表
        """
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                query = quote(f"all:{topic}")
                url = f"{settings.arxiv_api_url}?search_query={query}&start=0&max_results={max_results}&sortBy=relevance"
                response = await client.get(url)

                if response.status_code != 200:
                    raise LiteratureSearchError("arXiv", f"HTTP {response.status_code}")

                root = ET.fromstring(response.text)
                ns = {"atom": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}

                literature_list = []
                for entry in root.findall("atom:entry", ns):
                    title = entry.find("atom:title", ns)
                    authors = entry.findall("atom:author/atom:name", ns)
                    summary = entry.find("atom:summary", ns)
                    published = entry.find("atom:published", ns)
                    doi = entry.find("arxiv:doi", ns)
                    link = entry.find("atom:id", ns)

                    literature_list.append(LiteratureResponse(
                        id=f"arxiv:{entry.find('atom:id', ns).text.split('/')[-1]}",
                        project_id="",
                        title=title.text.replace("\n", " ").strip() if title is not None else "",
                        authors=", ".join([a.text for a in authors]) if authors else "",
                        abstract=summary.text.replace("\n", " ").strip() if summary is not None else None,
                        publication_year=int(published.text[:4]) if published is not None else None,
                        citation_key=self.generate_citation_key(", ".join([a.text for a in authors]) if authors else "", int(published.text[:4]) if published is not None else 2024),
                        source="arXiv",
                        doi=doi.text if doi is not None else None,
                        url=link.text if link is not None else None,
                        cached_at=datetime.utcnow()
                    ))

                return literature_list
        except LiteratureSearchError:
            raise
        except Exception as e:
            self.log_error(f"arXiv检索失败: {str(e)}")
            return []

    async def _search_semantic_scholar(self, topic: str, max_results: int) -> List[LiteratureResponse]:
        """
        从Semantic Scholar检索文献

        Args:
            topic: 检索主题
            max_results: 最大结果数

        Returns:
            List[LiteratureResponse]: Semantic Scholar文献列表
        """
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                url = f"{settings.semantic_scholar_api_url}/paper/search"
                headers = {"Accept": "application/json"}
                params = {
                    "query": topic,
                    "limit": max_results,
                    "fields": "title,authors,abstract,year,externalIds,url"
                }
                response = await client.get(url, headers=headers, params=params)

                if response.status_code != 200:
                    raise LiteratureSearchError("Semantic Scholar", f"HTTP {response.status_code}")

                data = response.json()
                literature_list = []

                for paper in data.get("data", []):
                    authors = paper.get("authors", [])
                    year = paper.get("year")
                    external_ids = paper.get("externalIds", {})

                    literature_list.append(LiteratureResponse(
                        id=f"ss:{paper.get('paperId', '')}",
                        project_id="",
                        title=paper.get("title", ""),
                        authors=", ".join([a.get("name", "") for a in authors[:5]]),
                        abstract=paper.get("abstract"),
                        publication_year=year,
                        citation_key=self.generate_citation_key(", ".join([a.get("name", "") for a in authors[:3]]), year or 2024),
                        source="Semantic Scholar",
                        doi=external_ids.get("DOI"),
                        url=paper.get("url"),
                        cached_at=datetime.utcnow()
                    ))

                return literature_list
        except LiteratureSearchError:
            raise
        except Exception as e:
            self.log_error(f"Semantic Scholar检索失败: {str(e)}")
            return []

    async def _search_crossref(self, topic: str, max_results: int) -> List[LiteratureResponse]:
        """
        从Crossref检索文献

        Args:
            topic: 检索主题
            max_results: 最大结果数

        Returns:
            List[LiteratureResponse]: Crossref文献列表
        """
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                url = f"{settings.crossref_api_url}"
                params = {
                    "query": topic,
                    "rows": max_results,
                    "select": "DOI,title,author,abstract,published-print,published-online,URL"
                }
                response = await client.get(url, params=params)

                if response.status_code != 200:
                    raise LiteratureSearchError("Crossref", f"HTTP {response.status_code}")

                data = response.json()
                literature_list = []

                for item in data.get("message", {}).get("items", []):
                    authors = item.get("author", [])
                    year = None
                    published = item.get("published-print") or item.get("published-online")
                    if published and "date-parts" in published:
                        year = published["date-parts"][0][0]

                    literature_list.append(LiteratureResponse(
                        id=f"crossref:{item.get('DOI', '')}",
                        project_id="",
                        title=item.get("title", [""])[0] if item.get("title") else "",
                        authors=", ".join([f"{a.get('given', '')} {a.get('family', '')}" for a in authors[:5]]),
                        abstract=item.get("abstract"),
                        publication_year=year,
                        citation_key=self.generate_citation_key(", ".join([a.get("family", "") for a in authors[:3]]), year or 2024),
                        source="Crossref",
                        doi=item.get("DOI"),
                        url=item.get("URL"),
                        cached_at=datetime.utcnow()
                    ))

                return literature_list
        except LiteratureSearchError:
            raise
        except Exception as e:
            self.log_error(f"Crossref检索失败: {str(e)}")
            return []

    def generate_citation_key(self, authors: str, year: int) -> str:
        """
        生成引用标识键

        Args:
            authors: 作者字符串
            year: 发表年份

        Returns:
            str: 引用标识键，如 [Zhang2024]
        """
        if not authors:
            return f"[Unknown{year}]"
        first_author = authors.split(",")[0].strip().split()[-1]
        return f"[{first_author}{year}]"

    def _deduplicate(self, literature: List[LiteratureResponse]) -> List[LiteratureResponse]:
        """
        对文献列表进行去重

        Args:
            literature: 文献列表

        Returns:
            List[LiteratureResponse]: 去重后的文献列表
        """
        seen_titles = set()
        unique = []
        for lit in literature:
            title_lower = lit.title.lower()
            if title_lower not in seen_titles and title_lower:
                seen_titles.add(title_lower)
                unique.append(lit)
        return unique
