"""
配置模块 - 管理应用配置和全局设置
"""
from pydantic_settings import BaseSettings
from pathlib import Path
from typing import Optional
import json

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
TEMPLATES_DIR = BASE_DIR / "backend" / "templates"

DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

class Settings(BaseSettings):
    """应用配置类，使用pydantic-settings从环境变量加载配置"""

    # 应用配置
    app_name: str = "学术论文写作助手"
    app_version: str = "1.0.0"
    debug: bool = False

    # 数据库配置
    database_url: str = f"sqlite+aiosqlite:///{DATA_DIR}/paper_assistant.db"

    # LLM配置
    default_model: str = "gpt-4"
    fallback_models: list[str] = ["gpt-3.5-turbo", "claude-3-sonnet"]
    api_base_url: Optional[str] = None
    max_retries: int = 3

    # 文献检索配置
    arxiv_api_url: str = "https://export.arxiv.org/api/query"
    semantic_scholar_api_url: str = "https://api.semanticscholar.org/graph/v1"
    crossref_api_url: str = "https://api.crossref.org/works"
    max_literature_results: int = 50

    # Token限制
    max_token_per_request: int = 8000
    daily_token_limit: int = 2000000

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()

def load_template(template_id: str) -> dict:
    """
    加载指定ID的格式模板

    Args:
        template_id: 模板唯一标识符

    Returns:
        dict: 模板配置字典

    Raises:
        FileNotFoundError: 模板文件不存在时抛出
    """
    template_path = TEMPLATES_DIR / f"{template_id}.json"
    if not template_path.exists():
        raise FileNotFoundError(f"模板 {template_id} 不存在")
    with open(template_path, "r", encoding="utf-8") as f:
        return json.load(f)

def get_available_templates() -> list[str]:
    """
    获取所有可用的格式模板列表

    Returns:
        list[str]: 可用模板ID列表
    """
    return [p.stem for p in TEMPLATES_DIR.glob("*.json")]
