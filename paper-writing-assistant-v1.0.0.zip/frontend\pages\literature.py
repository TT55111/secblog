"""
文献检索页面 - 处理文献搜索和管理
"""
import streamlit as st
import requests

def main():
    """文献检索页面主函数"""
    st.header("文献检索")

    if not st.session_state.get("current_project"):
        st.warning("请先在「项目管理」中选择一个项目")
        return

    project = st.session_state.current_project

    with st.form("search_form"):
        col1, col2 = st.columns([4, 1])
        with col1:
            topic = st.text_input("搜索主题", placeholder="输入研究主题或关键词")
        with col2:
            max_results = st.number_input("最大结果数", min_value=5, max_value=100, value=20)
        submitted = st.form_submit_button("🔍 搜索文献", type="primary")

        if submitted and topic:
            with st.spinner("正在检索文献..."):
                try:
                    response = requests.post(
                        f"{st.session_state.api_base_url}/api/projects/{project['id']}/literature/search",
                        json={"topic": topic, "max_results": max_results}
                    )
                    if response.status_code == 200:
                        data = response.json()
                        st.success(f"检索到 {data['total']} 条文献")
                        st.session_state.literature = data.get("data", [])
                    else:
                        st.error(f"检索失败: {response.text}")
                except Exception as e:
                    st.error(f"连接错误: {str(e)}")

    if "literature" in st.session_state and st.session_state.literature:
        st.divider()
        st.subheader(f"文献列表 ({len(st.session_state.literature)})")

        for lit in st.session_state.literature:
            with st.expander(f"📚 {lit['title']}"):
                st.write(f"**作者**: {lit['authors']}")
                st.write(f"**年份**: {lit['publication_year']}")
                st.write(f"**来源**: {lit['source']}")
                st.write(f"**引用键**: {lit['citation_key']}")
                if lit.get("abstract"):
                    st.write(f"**摘要**: {lit['abstract'][:200]}...")
                if lit.get("doi"):
                    st.write(f"**DOI**: {lit['doi']}")

if __name__ == "__main__":
    main()
