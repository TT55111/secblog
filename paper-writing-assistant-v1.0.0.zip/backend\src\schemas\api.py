"""
API请求/响应模型 - 定义所有API端点的Pydantic模型
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime
from enum import Enum

class ProjectStatus(str, Enum):
    """项目状态枚举"""
    DRAFT = "draft"
    OUTLINE_COMPLETE = "outline_complete"
    DRAFT_COMPLETE = "draft_complete"
    FINAL = "final"

class ExportFormat(str, Enum):
    """导出格式枚举"""
    DOCX = "docx"
    PDF = "pdf"
    LATEX = "latex"
    MD = "md"

# ============ 项目Schema ============
class ProjectCreate(BaseModel):
    """创建项目的请求模型"""
    title: str = Field(..., min_length=1, max_length=500)
    topic: str = Field(..., min_length=1, max_length=1000)
    format_template: str = Field(default="gb_t_7714")

class ProjectUpdate(BaseModel):
    """更新项目的请求模型"""
    title: Optional[str] = Field(None, max_length=500)
    topic: Optional[str] = Field(None, max_length=1000)
    format_template: Optional[str] = None
    status: Optional[ProjectStatus] = None

class ProjectResponse(BaseModel):
    """项目响应模型"""
    id: str
    title: str
    topic: str
    format_template: str
    status: ProjectStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class ProjectListResponse(BaseModel):
    """项目列表响应模型"""
    success: bool = True
    data: List[ProjectResponse]
    total: int

# ============ 文献Schema ============
class LiteratureCreate(BaseModel):
    """创建文献的请求模型"""
    title: str
    authors: str
    abstract: Optional[str] = None
    publication_year: Optional[int] = None
    source: Optional[str] = None
    doi: Optional[str] = None
    url: Optional[str] = None

class LiteratureResponse(BaseModel):
    """文献响应模型"""
    id: str
    project_id: str
    title: str
    authors: str
    abstract: Optional[str]
    publication_year: Optional[int]
    citation_key: Optional[str]
    source: Optional[str]
    doi: Optional[str]
    url: Optional[str]
    cached_at: datetime

    class Config:
        from_attributes = True

class LiteratureSearchRequest(BaseModel):
    """文献搜索请求模型"""
    topic: str = Field(..., min_length=1)
    max_results: int = Field(default=20, ge=1, le=100)

class LiteratureSearchResponse(BaseModel):
    """文献搜索响应模型"""
    success: bool = True
    data: List[LiteratureResponse]
    total: int

# ============ 大纲Schema ============
class OutlineSection(BaseModel):
    """大纲章节模型"""
    id: str
    title: str
    level: int
    description: Optional[str] = None
    word_count_target: Optional[int] = None
    children: List["OutlineSection"] = []

class OutlineStructure(BaseModel):
    """大纲结构模型"""
    paper_type: str
    total_words: int
    sections: List[OutlineSection]

class OutlineGenerateRequest(BaseModel):
    """生成大纲的请求模型"""
    paper_type: Optional[str] = None

class OutlineResponse(BaseModel):
    """大纲响应模型"""
    id: str
    project_id: str
    structure: OutlineStructure
    generated_at: datetime
    user_modified: bool

    class Config:
        from_attributes = True

# ============ 内容Schema ============
class ContentGenerateRequest(BaseModel):
    """生成内容的请求模型"""
    section_id: str
    context: Optional[str] = None

class ContentUpdate(BaseModel):
    """更新内容的请求模型"""
    content: str

class ContentResponse(BaseModel):
    """内容响应模型"""
    id: str
    project_id: str
    section_id: str
    section_title: Optional[str]
    content: Optional[str]
    ai_generated: bool
    token_count: int
    generated_at: datetime

    class Config:
        from_attributes = True

# ============ 校验Schema ============
class ValidationError(BaseModel):
    """校验错误模型"""
    section_id: Optional[str]
    error_type: str
    message: str
    location: Optional[str] = None
    suggestion: Optional[str] = None

class ValidationReport(BaseModel):
    """校验报告模型"""
    total_errors: int
    errors: List[ValidationError]
    warnings: List[str]

class ValidationResponse(BaseModel):
    """校验响应模型"""
    success: bool = True
    data: ValidationReport

# ============ 导出Schema ============
class ExportRequest(BaseModel):
    """导出请求模型"""
    format: ExportFormat
    include_abstract: bool = True
    include_references: bool = True

class ExportResponse(BaseModel):
    """导出响应模型"""
    success: bool = True
    data: dict
    message: str

# ============ 配置Schema ============
class LLMConfig(BaseModel):
    """LLM配置模型"""
    model: str
    api_key: Optional[str] = None
    api_base: Optional[str] = None

class ConfigResponse(BaseModel):
    """配置响应模型"""
    available_models: List[str]
    available_templates: List[str]
    current_model: str

class ConfigUpdate(BaseModel):
    """配置更新模型"""
    model: Optional[str] = None
    api_key: Optional[str] = None
    api_base: Optional[str] = None

# ============ 通用响应 ============
class SuccessResponse(BaseModel):
    """成功响应模型"""
    success: bool = True
    message: str

class ErrorDetail(BaseModel):
    """错误详情模型"""
    code: str
    message: str
    details: Optional[str] = None
    recoverable: bool = True
    suggestion: Optional[str] = None

class ErrorResponse(BaseModel):
    """错误响应模型"""
    success: bool = False
    error: ErrorDetail

OutlineSection.model_rebuild()
