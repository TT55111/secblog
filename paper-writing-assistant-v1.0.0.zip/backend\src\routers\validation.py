"""
格式校验路由 - 处理论文格式校验
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from database import get_db
from models.project import Project
from models.outline import Outline
from models.content import Content
from schemas.api import ValidationResponse
from schemas.api import OutlineSection
from agents.format_validation import FormatValidationAgent
from utils.logger import get_logger

router = APIRouter(prefix="/api/projects/{project_id}/validate", tags=["格式校验"])
logger = get_logger("router.validation")
validation_agent = FormatValidationAgent()

@router.post("", response_model=ValidationResponse)
async def validate_format(project_id: str, db: AsyncSession = Depends(get_db)):
    """校验论文格式"""
    project = (await db.execute(select(Project).where(Project.id == project_id))).scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="项目不存在")

    outline = (await db.execute(select(Outline).where(Outline.project_id == project_id))).scalar_one_or_none()
    if not outline:
        raise HTTPException(status_code=404, detail="大纲不存在")

    contents = (await db.execute(select(Content).where(Content.project_id == project_id))).scalars().all()

    outline_sections = [OutlineSection(**s) for s in outline.structure.get("sections", [])]

    report = await validation_agent.execute(
        contents=contents,
        outline=outline_sections,
        template_id=project.format_template
    )

    return ValidationResponse(success=True, data=report)
