"""
Streamlit主应用 - 学术论文写作助手前端入口
"""
import streamlit as st
import requests
import os

API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(
    page_title="学术论文写作助手",
    page_icon="📝",
    layout="wide",
    initial_sidebar_state="expanded"
)

PAGES = {
    "📁 项目管理": "projects",
    "🔍 文献检索": "literature",
    "📝 大纲规划": "outline",
    "✍️ 内容撰写": "content",
    "✅ 格式校验": "validation",
    "⚙️ 设置": "settings"
}

def init_session():
    """初始化会话状态"""
    if "current_project" not in st.session_state:
        st.session_state.current_project = None
    if "api_base_url" not in st.session_state:
        st.session_state.api_base_url = API_BASE_URL

def check_api_health():
    """检查API服务健康状态"""
    try:
        response = requests.get(f"{st.session_state.api_base_url}/health", timeout=2)
        return response.status_code == 200
    except:
        return False

init_session()

with st.sidebar:
    st.title("📝 学术论文写作助手")
    st.divider()

    if not check_api_health():
        st.error("⚠️ 后端服务未连接，请确保FastAPI服务正在运行")
        if st.button("重试连接"):
            st.rerun()
    else:
        st.success("✅ 服务已连接")

    st.divider()
    selected_page = st.radio("导航", list(PAGES.keys()))

st.title(selected_page)

page_module_name = f"pages.{PAGES[selected_page]}"
try:
    page_module = __import__(page_module_name, fromlist=["main"])
    page_module.main()
except Exception as e:
    st.error(f"页面加载失败: {str(e)}")
